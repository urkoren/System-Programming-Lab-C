#ifndef INCLUDES_H_
#define INCLUDES_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#endif /* INCLUDES_H_ */
