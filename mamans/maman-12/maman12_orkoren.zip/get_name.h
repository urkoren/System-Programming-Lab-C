#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NUM_NAMES   30
#define NAME_LEN    20

char *get_name(void);
int insert_names(void);
